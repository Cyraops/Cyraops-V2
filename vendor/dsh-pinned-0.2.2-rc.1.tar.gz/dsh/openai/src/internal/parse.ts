import type { FinalRequestOptions } from './request-options';
import { Stream } from '../core/streaming';
import { type OpenAI } from '../client';
import { isAbortError } from './errors';
import { formatRequestDetails, loggerFor } from './utils/log';
import type { AbstractPage } from '../pagination';

export type APIResponseProps = {
  response: Response;
  options: FinalRequestOptions;
  controller: AbortController;
  requestSignal?: AbortSignal | null | undefined;
  requestLogID: string;
  retryOfRequestLogID: string | undefined;
  startTime: number;
};

export async function defaultParseResponse<T>(
  client: OpenAI,
  props: APIResponseProps,
): Promise<WithRequestID<T>> {
  const { response, requestLogID, retryOfRequestLogID, startTime } = props;
  let jsonBodyLength: number | undefined;
  const body = await (async () => {
    if (props.options.stream) {
      loggerFor(client).debug('response', response.status, response.url, response.headers, response.body);

      // Note: there is an invariant here that isn't represented in the type system
      // that if you set `stream: true` the response type must also be `Stream<T>`

      if (props.options.__streamClass) {
        return props.options.__streamClass.fromSSEResponse(
          response,
          props.controller,
          client,
          props.options.__synthesizeEventData,
        ) as any;
      }

      return Stream.fromSSEResponse(
        response,
        props.controller,
        client,
        props.options.__synthesizeEventData,
      ) as any;
    }

    // fetch refuses to read the body when the status code is 204.
    if (response.status === 204) {
      return null as T;
    }

    if (props.options.__binaryResponse) {
      return response as unknown as T;
    }

    const contentType = response.headers.get('content-type');
    const mediaType = contentType?.split(';')[0]?.trim().toLowerCase();
    const isJSON = mediaType?.includes('application/json') || mediaType?.endsWith('+json');
    if (isJSON) {
      const contentLength = response.headers.get('content-length');
      if (contentLength === '0') {
        // if there is no content we can't do anything
        return undefined as T;
      }

      const bodyText = await response.text();
      if (!bodyText) {
        // Some servers respond with an empty body and a JSON content-type but
        // without a `content-length: 0` header (e.g. over HTTP/2 or with chunked
        // transfer encoding). Treat this the same as an explicit `content-length: 0`
        // instead of letting `JSON.parse` throw an opaque `SyntaxError`.
        return undefined as T;
      }

      const json = JSON.parse(bodyText);
      jsonBodyLength = bodyText.length;
      return addRequestID(json as T, response);
    }

    const text = await response.text();
    return text as unknown as T;
  })().catch((error: unknown) => {
    throw asAbortError(error, props.controller.signal);
  });
  if (client.logLevel === 'debug') {
    loggerFor(client).debug(
      `[${requestLogID}] response parsed`,
      formatRequestDetails({
        retryOfRequestLogID,
        url: response.url,
        status: response.status,
        body: jsonBodyLength === undefined ? body : { type: 'json', length: jsonBodyLength },
        durationMs: Date.now() - startTime,
      }),
    );
  }
  return body;
}

function asAbortError(error: unknown, signal: AbortSignal): unknown {
  if (!signal.aborted || error !== signal.reason || isAbortError(error)) {
    return error;
  }

  const message = 'This operation was aborted';
  const DOMExceptionConstructor = (globalThis as any).DOMException;
  return typeof DOMExceptionConstructor === 'function'
    ? new DOMExceptionConstructor(message, 'AbortError')
    : Object.assign(new Error(message), { name: 'AbortError' });
}

export type WithRequestID<T> = T extends Array<any> | Response | AbstractPage<any>
  ? T
  : T extends Record<string, any>
    ? T & { _request_id?: string | null }
    : T;

export function addRequestID<T>(value: T, response: Response): WithRequestID<T> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    return value as WithRequestID<T>;
  }

  return Object.defineProperty(value, '_request_id', {
    value: response.headers.get('x-request-id'),
    enumerable: false,
  }) as WithRequestID<T>;
}
